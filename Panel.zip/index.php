<?php
session_start();

error_reporting(0);

if (file_exists("install.php"))
  {
    header("Location: install.php");
    exit();
  }

if (isset($_GET['cmd']))
  {
    session_start();
    session_destroy();
    header('Location: index.php');
    exit();
  }

require_once('inc/config.php');

if ($_SESSION['login'])
  {
    header('Location: home.php');
    exit();
  }

$user = $_POST[user];
$pass = md5($_POST[pass]);
if (isset($_POST['login']))
  {
    if ($user == $correctuser && $pass == $correctpass)
      {
        $_SESSION['login']    = true;
        $_SESSION['username'] = $user;
        header('Location: home.php');
      }
    else
      {
        
        $error = '<center><img src="img/error.gif" height="170" weight="300"/></center><br>';
        $alert = '<div id="wrong" style="width:100%; padding: 10px; background:#a52a2a"><a><center><font color="white">&nbsp;Неправильный пароль!</font></center></a></div>';
      }
  }
  
  $n = rand(1,6);
  
?>

<html>
  
  <head>
    
    <meta charset="UTF-8">
    
    <title>
      вход
    </title>
    
    <script src="js/prefixfree.min.js">
  </script>
  <link rel="stylesheet" href="css/normalize.css"/>
  <link rel="stylesheet" href="css/style-login.css"/>
  
  </head>	
  
  <body>
  
    <?
  	echo $alert;
    ?>
    
    <div class="login">
      
      <center>
         <?php 
	  if($error == '')
	   {
	    echo '<img src="img/kartoxa'; echo $n.'.png" height="200" weight="200"/>';
	   }
	  else
	   {
	    echo $error;
	   } 
	 ?>
      </center>
      <form action="index.php" method="post">
    	<input type="text" name="user" placeholder="логин" required="required" />
      <input type="password" name="pass" placeholder="пароль" required="required" />
      <button type="submit" name="login" class="btn btn-primary btn-block btn-large">
        Войти
      </button>
    </form>
  </div>
  
  
  </body>
  
</html>