      function new_window(url) {
          link = window.open(url, "Link", "toolbar=0,location=0,directories=0,status=0,menubar=0,scrollbars=yes,resizable=0,width=780,height=350,left=80,top=180");
      }